package com.example.audiocapture.ui

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.audiocapture.databinding.ActivityMainBinding
import com.example.audiocapture.service.AudioCaptureService

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var mediaProjectionManager: MediaProjectionManager
    
    private var isCapturing = false
    private var serverUri: String = ""
    
    companion object {
        private const val REQUEST_CODE_SCREEN_CAPTURE = 100
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        mediaProjectionManager = getSystemService(MediaProjectionManager::class.java)
        
        setupUI()
    }
    
    private fun setupUI() {
        // 设置默认服务器地址
        binding.etServerUri.setText("ws://192.168.1.100:8765")
        
        binding.btnStart.setOnClickListener {
            if (isCapturing) {
                stopCapture()
            } else {
                startCapture()
            }
        }
        
        binding.btnStop.setOnClickListener {
            stopCapture()
        }
        
        updateUI()
    }
    
    private fun startCapture() {
        serverUri = binding.etServerUri.text.toString().trim()
        
        if (serverUri.isEmpty()) {
            Toast.makeText(this, "请输入服务器地址", Toast.LENGTH_SHORT).show()
            return
        }
        
        if (!serverUri.startsWith("ws://") && !serverUri.startsWith("wss://")) {
            Toast.makeText(this, "服务器地址格式错误", Toast.LENGTH_SHORT).show()
            return
        }
        
        // 请求屏幕录制权限
        val captureIntent = mediaProjectionManager.createScreenCaptureIntent()
        startActivityForResult(captureIntent, REQUEST_CODE_SCREEN_CAPTURE)
    }
    
    private fun stopCapture() {
        val stopIntent = Intent(this, AudioCaptureService::class.java).apply {
            action = AudioCaptureService.ACTION_STOP
        }
        startService(stopIntent)
        
        isCapturing = false
        updateUI()
        Toast.makeText(this, "已停止捕获", Toast.LENGTH_SHORT).show()
    }
    
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        
        if (requestCode == REQUEST_CODE_SCREEN_CAPTURE) {
            if (resultCode == Activity.RESULT_OK && data != null) {
                // 启动音频捕获服务
                val startIntent = Intent(this, AudioCaptureService::class.java).apply {
                    action = AudioCaptureService.ACTION_START
                    putExtra(AudioCaptureService.EXTRA_SERVER_URI, serverUri)
                    putExtra(AudioCaptureService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(AudioCaptureService.EXTRA_RESULT_DATA, data)
                }
                
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    startForegroundService(startIntent)
                } else {
                    startService(startIntent)
                }
                
                isCapturing = true
                updateUI()
                Toast.makeText(this, "开始捕获音频", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "用户拒绝了屏幕录制权限", Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    private fun updateUI() {
        if (isCapturing) {
            binding.btnStart.text = "停止捕获"
            binding.etServerUri.isEnabled = false
            binding.btnStop.isEnabled = true
        } else {
            binding.btnStart.text = "开始捕获"
            binding.etServerUri.isEnabled = true
            binding.btnStop.isEnabled = false
        }
    }
}

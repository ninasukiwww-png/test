package com.example.audiocapture.websocket

import android.util.Log
import org.java_websocket.client.WebSocketClient
import org.java_websocket.handshake.ServerHandshake
import java.net.URI
import java.nio.ByteBuffer

class WebSocketManager(
    private val serverUri: String,
    private val onMessage: (String) -> Unit,
    private val onError: (Exception) -> Unit
) {
    private var webSocketClient: WebSocketClient? = null
    private var isConnected = false
    
    fun connect() {
        try {
            val uri = URI(serverUri)
            webSocketClient = object : WebSocketClient(uri) {
                override fun onOpen(handshakedata: ServerHandshake?) {
                    Log.d("WebSocket", "Connected to $serverUri")
                    isConnected = true
                    onMessage("Connected to server")
                }
                
                override fun onMessage(message: String?) {
                    message?.let { onMessage(it) }
                }
                
                override fun onMessage(bytes: ByteBuffer?) {
                    // 处理二进制消息
                    bytes?.let {
                        val data = ByteArray(it.remaining())
                        it.get(data)
                        Log.d("WebSocket", "Received binary data: ${data.size} bytes")
                    }
                }
                
                override fun onClose(code: Int, reason: String?, remote: Boolean) {
                    Log.d("WebSocket", "Disconnected: $reason")
                    isConnected = false
                    onMessage("Disconnected: $reason")
                }
                
                override fun onError(ex: Exception?) {
                    Log.e("WebSocket", "Error", ex)
                    ex?.let { onError(it) }
                }
            }
            
            webSocketClient?.connect()
        } catch (e: Exception) {
            onError(e)
        }
    }
    
    fun sendAudioData(data: ByteArray) {
        if (isConnected && webSocketClient?.isOpen == true) {
            try {
                webSocketClient?.send(data)
            } catch (e: Exception) {
                Log.e("WebSocket", "Failed to send audio data", e)
            }
        }
    }
    
    fun disconnect() {
        webSocketClient?.close()
        webSocketClient = null
        isConnected = false
    }
    
    fun isConnected(): Boolean = isConnected
}

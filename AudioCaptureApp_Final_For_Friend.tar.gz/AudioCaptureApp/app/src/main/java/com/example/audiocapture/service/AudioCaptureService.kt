package com.example.audiocapture.service

import android.app.*
import android.content.Intent
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.audiocapture.R
import com.example.audiocapture.ui.MainActivity
import com.example.audiocapture.websocket.WebSocketManager
import kotlinx.coroutines.*

class AudioCaptureService : Service() {
    private val CHANNEL_ID = "AudioCaptureChannel"
    private val NOTIFICATION_ID = 1
    
    private var mediaProjection: MediaProjection? = null
    private var audioRecord: AudioRecord? = null
    private var webSocketManager: WebSocketManager? = null
    private var captureJob: Job? = null
    
    private lateinit var mediaProjectionManager: MediaProjectionManager
    
    override fun onCreate() {
        super.onCreate()
        mediaProjectionManager = getSystemService(MediaProjectionManager::class.java)
        createNotificationChannel()
    }
    
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val serverUri = intent.getStringExtra(EXTRA_SERVER_URI)
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val resultData = intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
                
                if (serverUri != null && resultData != null) {
                    startCapture(serverUri, resultCode, resultData)
                }
            }
            ACTION_STOP -> {
                stopCapture()
                stopSelf()
            }
        }
        
        return START_STICKY
    }
    
    private fun startCapture(serverUri: String, resultCode: Int, resultData: Intent) {
        // 创建前台通知
        startForeground(NOTIFICATION_ID, createNotification())
        
        // 初始化WebSocket
        webSocketManager = WebSocketManager(
            serverUri = serverUri,
            onMessage = { message ->
                Log.d("AudioCapture", "WebSocket: $message")
            },
            onError = { error ->
                Log.e("AudioCapture", "WebSocket error", error)
                stopCapture()
            }
        )
        
        webSocketManager?.connect()
        
        // 等待WebSocket连接
        CoroutineScope(Dispatchers.IO).launch {
            delay(1000) // 等待连接建立
            
            // 初始化MediaProjection
            mediaProjection = mediaProjectionManager.getMediaProjection(resultCode, resultData)
            
            // 配置音频捕获
            val config = AudioPlaybackCaptureConfiguration.Builder(mediaProjection!!)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .build()
            
            val format = AudioFormat.Builder()
                .setSampleRate(16000)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                .build()
            
            val minBufferSize = AudioRecord.getMinBufferSize(
                16000,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            
            audioRecord = AudioRecord.Builder()
                .setAudioPlaybackCaptureConfig(config)
                .setAudioFormat(format)
                .setBufferSizeInBytes(minBufferSize * 2)
                .build()
            
            audioRecord?.startRecording()
            
            // 开始捕获音频数据
            captureJob = CoroutineScope(Dispatchers.IO).launch {
                val buffer = ByteArray(320) // 10ms的数据 (16000 * 2 * 0.01)
                
                while (isActive) {
                    val bytesRead = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                    if (bytesRead > 0) {
                        webSocketManager?.sendAudioData(buffer.copyOf(bytesRead))
                    }
                    delay(10) // 10ms间隔
                }
            }
            
            Log.d("AudioCapture", "Audio capture started")
        }
    }
    
    private fun stopCapture() {
        captureJob?.cancel()
        captureJob = null
        
        audioRecord?.stop()
        audioRecord?.release()
        audioRecord = null
        
        mediaProjection?.stop()
        mediaProjection = null
        
        webSocketManager?.disconnect()
        webSocketManager = null
        
        stopForeground(STOP_FOREGROUND_REMOVE)
        Log.d("AudioCapture", "Audio capture stopped")
    }
    
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Audio Capture",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Audio capture service is running"
            }
            
            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }
    }
    
    private fun createNotification(): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Audio Capture")
            .setContentText("Capturing audio...")
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }
    
    override fun onBind(intent: Intent?): IBinder? = null
    
    override fun onDestroy() {
        stopCapture()
        super.onDestroy()
    }
    
    companion object {
        const val ACTION_START = "ACTION_START"
        const val ACTION_STOP = "ACTION_STOP"
        const val EXTRA_SERVER_URI = "EXTRA_SERVER_URI"
        const val EXTRA_RESULT_CODE = "EXTRA_RESULT_CODE"
        const val EXTRA_RESULT_DATA = "EXTRA_RESULT_DATA"
    }
}
